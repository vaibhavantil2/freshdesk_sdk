(function() {
  return {
    initialize: function() {
      console.log("My first app!");
    }
  }
})();
