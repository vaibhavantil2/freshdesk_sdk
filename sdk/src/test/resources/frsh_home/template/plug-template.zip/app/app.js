(function() {
  return {
    init: function() {
      // Place your plug js here.. 
    }
  }
})();